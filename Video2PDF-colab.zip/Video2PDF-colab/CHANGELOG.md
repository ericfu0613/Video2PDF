* 7/17 下載字幕改用 `whisper-ctranslate2` 下載英文字木
* 7/17 合成字幕改為字幕的中間點
