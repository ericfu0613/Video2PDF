import os
import sys
from moviepy.editor import *
from moviepy.editor import TextClip

print(TextClip.list("font"))
print(TextClip.list('color'))
# 列出你可以使用哪些 Font
